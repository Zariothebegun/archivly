// app.js
// Funções pequenas e reutilizadas em ambas as páginas (login e dashboard).

function guardarToken(token) {
  localStorage.setItem("archivly_token", token);
}

function obterToken() {
  return localStorage.getItem("archivly_token");
}

function limparToken() {
  localStorage.removeItem("archivly_token");
}

async function chamarAPI(endpoint, metodo = "GET", corpo = null) {
  const opcoes = {
    method: metodo,
    headers: {
      "Authorization": "Bearer " + obterToken(),
      "Content-Type": "application/json",
    },
  };
  if (corpo) opcoes.body = JSON.stringify(corpo);

  const resposta = await fetch(endpoint, opcoes);
  const json = await resposta.json();

  if (!resposta.ok) {
    if (resposta.status === 401) {
      limparToken();
      window.location.href = "/";
    }
    throw new Error(json.detail || "Erro na aplicação.");
  }
  return json;
}
